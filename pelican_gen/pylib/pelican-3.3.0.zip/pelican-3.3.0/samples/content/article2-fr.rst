Deuxième article
################

:tags: foo, bar, baz
:date: 2012-02-29
:lang: fr
:slug: second-article

Ceci est un article, en français.
