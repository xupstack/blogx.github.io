Conventions
###########

Environnement de test
=====================

Les exemples sont basées sur une distribution Debian. Pour les autres distributions,
il y aura des ajustements à faire, notamment pour l’installation de Pelican. Les
noms des paquets peuvent changer.

Conventions typographiques
==========================

Un petit rappel concernant les codes sources.

 *  $ correspond à une ligne à exécuter en tant qu’utilisateur courant du systême ;
 * # correspond à une ligne à exécuter en tant que root ;
 * **settings.py** : Les noms des répertoires et fichiers sont en gras.
