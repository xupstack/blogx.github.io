Title: Article with markdown containing footnotes
Date: 2012-10-31
Summary: Summary with **inline** markup *should* be supported.

This is some content[^1] with some footnotes[^footnote]

[^1]: Numbered footnote
[^footnote]: Named footnote