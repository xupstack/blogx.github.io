
Rst with filename metadata
##########################

:category: yeah
:author: Alexis Métaireau
