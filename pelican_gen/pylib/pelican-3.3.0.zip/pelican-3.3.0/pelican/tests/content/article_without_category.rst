
This is an article without category !
#####################################

This article should be in the DEFAULT_CATEGORY.

