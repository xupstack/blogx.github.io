
This is a super article !
#########################

:tags: foo, bar, foobar
:date: 2010-12-02 10:14
:category: yeah
:author: Alexis Métaireau
:summary:
    Multi-line metadata should be supported
    as well as **inline markup**.
:custom_field: http://notmyidea.org
