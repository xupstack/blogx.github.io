Title: Article with markdown and summary metadata multi
Date: 2012-10-31
Summary:
    A multi-line summary should be supported
    as well as **inline markup**.

This is some content.
