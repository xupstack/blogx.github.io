import logging
logging.getLogger().addHandler(logging.NullHandler())
